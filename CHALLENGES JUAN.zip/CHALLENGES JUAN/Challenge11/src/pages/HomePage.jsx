import React from 'react'

export const HomePage = () => {
  return (
    <div>Pagina1</div>
  )
}

