import React from 'react'

export const LoginPage = () => {
  return (
    <div>Pagina3</div>
  )
}

