import React from 'react'

export const AboutPage = () => {
  return (
    <div>Pagina2</div>
  )
}

