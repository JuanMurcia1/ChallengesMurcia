import React from "react";
import { useState } from "react";
import AddCategory from "./AddCategory";
import GifGrid from "./GifGrid";

const MyComponent2 = ()=>{

    const[categories,setCagetories]= useState([])

    const onAddCategory=(category)=>{
        setCagetories(list=>[...list,category]

        )
    }

    return(
        <div>

            <AddCategory onAddCategory={
                onAddCategory}/>
            {
                categories.map((category,key)=>{return <GifGrid category={category} key={key}/>})
            }
            
        </div>
    )



}

export default MyComponent2




