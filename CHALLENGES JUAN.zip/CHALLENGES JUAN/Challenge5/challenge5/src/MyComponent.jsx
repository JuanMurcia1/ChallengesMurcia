import React from 'react';
import UseFetch from './UseFetch'; // Asegúrate de importar correctamente el hook

const MyComponent = () => {
  const { data, isLoading, hasError } = UseFetch(`https://api.giphy.com/v1/gifs/search?api_key=eAtY1pE7EXegmfV8ZO3dPR3c3ApG7Ndz&q=1&limit=1&offset=0&rating=g&lang=en&bundle=messaging_non_clips`);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (hasError) {
    return <div>Error: {hasError}</div>;
  }

  return (
    <div>
      <h1>Data</h1>
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  );
};

export default MyComponent;
