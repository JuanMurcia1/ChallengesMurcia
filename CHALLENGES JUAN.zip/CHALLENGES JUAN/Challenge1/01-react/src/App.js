function App(){
  return (
    <>
    <h1> Hola Mundo</h1>
    <h2> Hola de qué pedazo de zunga</h2>
    </>
  
  )
}
export default App;