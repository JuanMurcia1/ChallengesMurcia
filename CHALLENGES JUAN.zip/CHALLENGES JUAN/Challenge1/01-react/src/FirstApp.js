function Textos(){
    return (
      <>
      <h1> Pandora</h1>
      <span> 10</span>
      </>
    
    )
  }
  export default Textos;